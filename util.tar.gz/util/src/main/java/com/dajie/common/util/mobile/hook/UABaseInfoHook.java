package com.dajie.common.util.mobile.hook;

/**
 * User: huihui.wang
 * Date: 13-2-1
 * Time: 下午4:43
 */
public abstract class UABaseInfoHook {

    public abstract String getVersion(String systemInfo);
}
